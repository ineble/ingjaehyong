## HotelFive
> 편리하고 빠른 숙소 예약을 위한 웹 페이지 제작 <br>

> 5인으로 구성된 팀 <br>

> 기여한 부분 : 아이디어 기획, DB 설계, Back End / 회원수정 및 탈퇴, 관리자페이지(회원목록 게시판, 예약현황 게시판)

- Spring Framework
- Mybatis
- HTML, CSS, BootStrap, JSP, AJAX
- Oracle

<br>
